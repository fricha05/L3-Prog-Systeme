extern void exo1(int argc, char ** argv);
extern void exo2(int argc, char ** argv);
extern void exo3(int argc, char ** argv);
extern void exo4(int argc, char ** argv);
extern void exo5(int argc, char ** argv);
extern void exo6(int argc, char ** argv);

int main(int argc, char ** argv) {
    exo1(argc, argv);
    exo2(argc, argv);
    exo3(argc, argv);
    exo4(argc, argv);
    exo5(argc, argv);
    exo6(argc, argv);
    return 0;
}
