#ifndef DISPLAY_FILES_H_INCLUDED
#define DISPLAY_FILES_H_INCLUDED

extern int is_dir(const char type);

extern int display(const char * path);
extern int display_file(const char * path);
extern int display_dir(const char * path);

extern int display_rec(const char * path, int recur);
extern int display_dir_rec(const char * path, int recur);

extern int display_ftw(const char * path, int recur);
extern int display_file_ftw(const char * path, const struct stat * buf, int recur);
extern int display_dir_ftw(const char * path, int recur);

#endif // DISPLAY_FILES_H_INCLUDED
