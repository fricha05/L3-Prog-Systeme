#ifndef STAT_H_INCLUDED
#define STAT_H_INCLUDED

extern char filetype(mode_t st_mode);
extern void affiche_infos(const struct stat * buf, char type, const char * s);
extern void affiche_inode(const struct stat * buf);
extern void affiche_link(const char * filename);

extern int is_link(const char type);

#endif /* STAT_H_INCLUDED*/
