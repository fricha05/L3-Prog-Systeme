#include "ex1.h"
#include "ex2.h"
#include "ex3.h"
#include "ex4.h"
#include "ex5.h"


int main(int argc, char* argv[]){
	/*myCat(argc, argv);
	myCp(argc, argv);
	redirect(argc, argv);
	redirect2(argc, argv);*/
	myWc(argc, argv);
	
	exit(EXIT_SUCCESS);
}
